ModUtil.RegisterMod("WebSocket")



  ModUtil.WrapBaseFunction( "MatchEndPresentation", function(baseFunc, ... )

    -- local textFile = io.open( ".\\Content\\Mods\\EloSocket\\log.txt", "w" )

    --Need to send Winning team, end team healths, and character codes (later)

    local message = {
      TeamAHealth = TeamA.PyreHealth,
      TeamBHealth = TeamB.PyreHealth,
      TeamACharacters = TeamA.AssignedCharacters,
      TeamBCharacters = TeamB.AssignedCharacters,
      modded = false
    }
    
    if TeamA.PyreHealth <= 0 then
      message.Winner = "B"
    elseif TeamB.PyreHealth <= 0 then
      message.Winner = "A"
    elseif TeamA.PyreHealth <= 0 and TeamB.PyreHealth <= 0 then
      message.Winner = "Tie"
    else
      message.Winner = "Error, What did you even do?"
    end
    HadesLive.send{
        target = 'record-match',
        message = message
    }
    -- textFile:write("Score")
    -- textFile:flush()
    -- textFile:close()

    return baseFunc(...)
end, WebSocket)
  -- log data in browser console

